# Privacy And Pseudonymisation

## Document control

- Document ID: K-020
- Status: approved
- Effective date: 2026-03-20
- Synthetic authority: NovaCura Global Policy
- Training classification: scenario evidence; not a real controlled document

## Purpose and scope

Defines minimization, re-identification assessment and controlled linkage.

## Mandatory controls

- Minimise data and separate direct identifiers from working data.
- Assess linkage and re-identification risk.
- Control access, purpose, retention and transfer.

## Evidence expected

- Source identity, version, effective date, responsible owner and retrieval time.
- Input records, transformations, conflicts, gaps, reviewer actions and resulting audit events.
- Any exception, escalation, override or residual risk with accountable approval.

## Prohibited use

- Do not treat this document as authority outside its status, jurisdiction, intended scope or effective period.
- Do not infer a regulated decision, execute a side effect, or hide conflicting evidence.

## Retrieval and conflict handling

The consumer must expose status, authority and effective date; detect supersession or untrusted content; cite the exact source; and abstain or escalate when applicability cannot be established.

This document is part of a fictional training scenario. Participants must determine authority, applicability, supersession and permitted use.
